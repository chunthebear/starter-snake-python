self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "f01ac2a36cfa70dbca18",
    "url": "/static/js/main.f01ac2a3.chunk.js"
  },
  {
    "revision": "a238762b1b5b93128f90",
    "url": "/static/js/1.a238762b.chunk.js"
  },
  {
    "revision": "cbfa2ca8265850aed183d2925aa69026",
    "url": "/index.html"
  }
];